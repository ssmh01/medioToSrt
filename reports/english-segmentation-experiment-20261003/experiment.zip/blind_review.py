from pathlib import Path
import json, random, hashlib
R=Path(__file__).resolve().parent;ws=json.loads((R/'windows-final_candidate-all.json').read_text());selected=[w for w in ws if w['kind']=='fixed'];m=json.loads((R/'manifest.json').read_text());keys={}
for d in m['samples']:
 pool=[w for w in ws if w['sample']==d['id'] and w['kind']=='changed'];rng=random.Random(2026100311+int(hashlib.sha256(d['id'].encode()).hexdigest()[:8],16));ix=sorted(rng.sample(range(len(pool)),min(6,len(pool))));selected.extend(pool[i] for i in ix)
rows=[];txt=[]
for i,w in enumerate(selected,1):
 rid=f'R{i:03}';rng=random.Random(2026100323+i);flip=rng.randrange(2);keys[rid]={'window_id':w['id'],'sample':w['sample'],'split':w['split'],'kind':w['kind'],'candidate_label':'A' if flip else 'B','changed':w['changed']};A=w['final_candidate'] if flip else w['baseline'];B=w['baseline'] if flip else w['final_candidate'];row={'id':rid,'source':w['source'],'A':A,'B':B};rows.append(row)
 # Remove identical context from display only, keep one boundary context at each side.
 aa=A.splitlines();bb=B.splitlines();pre=0
 while pre<min(len(aa),len(bb)) and aa[pre]==bb[pre]:pre+=1
 suf=0
 while suf<min(len(aa)-pre,len(bb)-pre) and aa[-1-suf]==bb[-1-suf]:suf+=1
 if A==B:display='IDENTICAL'
 else:
  lo=max(0,pre-1);ea=len(aa)-max(0,suf-1);eb=len(bb)-max(0,suf-1);display='A:\n'+'\n'.join(aa[lo:ea])+'\nB:\n'+'\n'.join(bb[lo:eb])
 txt.append(rid+'\n'+display+'\n')
(R/'review-blinded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));(R/'review-key.json').write_text(json.dumps(keys,ensure_ascii=False,indent=2));(R/'review-blinded.txt').write_text('\n'.join(txt));print('Review units',len(rows))
