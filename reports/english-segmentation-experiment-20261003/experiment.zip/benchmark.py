"""Sequential warm replay benchmark; no alignment/model API requests."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--variant', choices=['baseline', 'final_candidate'], required=True)
args = parser.parse_args()
sys.path.insert(0, str(ROOT / args.variant / 'src'))
from autosrt_aligner.models import AlignmentToken, SourceDocument
from autosrt_aligner.profiles import resolve_profile
from autosrt_aligner.segmenter_v2 import segment_cues

manifest = json.loads((ROOT / 'manifest.json').read_text())
sample = next(s for s in manifest['samples'] if s['id'] == 'en-da47bc4a61d2')
input_path = ROOT / 'inputs' / sample['id'] / 'alignment.json'
assert hashlib.sha256(input_path.read_bytes()).hexdigest() == sample['input_sha256']
data = json.loads(input_path.read_text())
s = data['source']
source = SourceDocument(s['display_text'], s['display_text'], s['align_text'], (), 'en', s['source_hash'])
tokens = [AlignmentToken(**t) for t in data['tokens']]
profile = resolve_profile('youtube_long', 'en', min_duration=1.2, max_duration=5.0, max_chars_total=60)

start = time.perf_counter()
cues = segment_cues(source, tokens, profile, audio_duration=sample['audio_duration'])
warmup_seconds = time.perf_counter() - start
expected = [(c.start_char, c.end_char, c.start, c.end) for c in cues]
times = []
for _ in range(3):
    start = time.perf_counter()
    cues = segment_cues(source, tokens, profile, audio_duration=sample['audio_duration'])
    times.append(time.perf_counter() - start)
    assert [(c.start_char, c.end_char, c.start, c.end) for c in cues] == expected
result = {
    'variant': args.variant,
    'sample': sample['id'],
    'audio_seconds': sample['audio_duration'],
    'warmup_seconds': warmup_seconds,
    'warm_repeats_seconds': times,
    'warm_median_seconds': statistics.median(times),
    'repeat_outputs_identical': True,
    'scope': 'Single long English source; sequential isolated processes; same local runtime; excludes audio alignment, API calls, export and evaluation; no general hardware performance claim.',
}
(ROOT / f'benchmark-{args.variant}.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False), flush=True)
