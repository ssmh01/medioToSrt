英语字幕切分独立实验包

入口：report.html、design.txt、summary.json。report.html 可直接用浏览器打开。

公平设置：1.2 秒一般最短 / 0.8 秒完整短句例外 / 5 秒最长 / 60 非空白字符 / 20 字符每秒；固定原文与历史对齐 token。
基线和冻结候选只在包内 src 快照上运行。请不要把 candidate.patch 直接应用到业务代码；其他语言尚未验证。

复现：在具备 requirements.txt 依赖的 Python 3.12 环境中，于解压目录执行：
python run.py --variant baseline --split all
python run.py --variant final_candidate --split all
python windows.py --variant final_candidate --split all
python benchmark.py --variant baseline
python benchmark.py --variant final_candidate

run.py 会重写包内 results 和对应摘要；这是已有时间证据的离线重切，不生成声音、不调用对齐模型。
candidate-freeze.json 记录候选冻结哈希；manifest.json 记录输入哈希及原始来源，脚本读取解压目录内 inputs。
完整 84 段评审是原实验意见，复现输出不会自动构成新的独立人工评审。
开发变体用 baseline 快照 + ablation-diffs 内对应差异复原；其逐项目 JSON 指标完整保留。
原输入真实音频未纳入包，未验证播放听感。prepare.py 是原实验建立过程的来源记录，不应重新执行以覆盖冻结输入。
