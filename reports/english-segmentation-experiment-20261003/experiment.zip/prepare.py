from pathlib import Path
import json, shutil, hashlib, datetime, subprocess
ROOT=Path('/private/tmp/english-segmentation-experiment-20261003'); REPO=Path('/Users/xieyulong/.codex/worktrees/2816/语音srt生成项目'); OLD=Path('/private/tmp/subtitle-naturalness-lab-20261003')
manifest=json.loads((OLD/'manifest.json').read_text()); inputs=[]
for d in manifest['datasets']:
 if d['language']=='en':
  inputs.append({'id':d['id'],'split':'development' if d['split']=='development' else 'validation','original_path':d['frozen_path']})
inputs.append({'id':'en-psychology-current','split':'regression','original_path':'/var/folders/1p/xrf8rcyd13j0x7s13cqdxkdc0000gn/T/autosrt_web_4b00d716-a8a1-4b20-99c8-66688958356e__vj2o7ds/alignment.json'})
for d in inputs:
 p=Path(d['original_path']); dest=ROOT/'inputs'/d['id'];dest.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest/'alignment.json')
 a=json.loads(p.read_text());d.update(input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),frozen_path=str(dest/'alignment.json'),characters=len(a['source']['display_text']),audio_duration=a['quality']['audio_duration'],source_hash=a['source']['source_hash'])
for name in ('baseline','grammar','grammar_sentence'):
 shutil.copytree(REPO/'src',ROOT/name/'src',dirs_exist_ok=True)
(ROOT/'manifest.json').write_text(json.dumps({'created_at_shanghai':datetime.datetime.now().isoformat(),'samples':inputs,'profile':{'style':'youtube_long','language':'en','min_duration':1.2,'max_duration':5.0,'max_chars_total':60,'max_chars_per_second':20},'protocol':{'development_samples':3,'validation_samples':2,'regression_samples':1,'constraints':['source exact ordered coverage','cue times from original selected token endpoints plus real terminal audio duration','no overlap','no word internal split','at most 60 nonwhitespace chars','at most 5 seconds','reading speed and minimum duration unchanged'],'evaluation':['fixed 8 source windows per content, source-position stratified seed 2026100307','review changed cut positions in context, classify clear gains and harms','dependency-risk metrics are proxies, never treated as semantic correctness','compare grammar-only and grammar+sentence variants before validation; freeze candidate before reading validation outputs'],'boundaries':['historical validation sources were viewed before this turn; not unseen external data','no realignment, model request, audio listening or service mutation','6 sources, 5 historical projects; excludes punctuation variants of the same source from independent count'],'selection_seed':2026100307},'repo_status_before':subprocess.check_output(['git','status','--short'],cwd=REPO,text=True),'repo_source_sha256':{str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [REPO/'src/autosrt_aligner/language_rules.py',REPO/'src/autosrt_aligner/segmenter_v2.py',REPO/'src/autosrt_aligner/profiles.py']}},ensure_ascii=False,indent=2))
# The English branch adds local grammatical connections to existing soft phrase scoring.
addition='''            if t.dep_ == "advmod" and t.head.pos_ in {"ADJ", "ADV", "ADP"}:
                a = min(t.idx, t.head.idx)
                b = max(t.idx + len(t), t.head.idx + len(t.head))
                if b - a <= 40:
                    atom(a, b, "degree_modifier")
            if t.dep_ == "prep" and t.head.pos_ in {"VERB", "AUX", "ADJ", "ADP"}:
                a = min(t.idx, t.head.idx)
                b = max(t.idx + len(t), t.head.idx + len(t.head))
                between = text[t.head.idx + len(t.head):t.idx]
                if t.idx > t.head.idx and len(between.strip().split()) <= 2 and b - a <= 40:
                    atom(a, b, "predicate_preposition_link")
            if t.dep_ == "dobj" and t.pos_ == "PRON" and t.head.pos_ == "VERB":
                a = min(t.idx, t.head.idx)
                b = max(t.idx + len(t), t.head.idx + len(t.head))
                if b - a <= 24:
                    atom(a, b, "verb_pronoun_object")
'''
for name in ('grammar','grammar_sentence'):
 p=ROOT/name/'src/autosrt_aligner/language_rules.py'; text=p.read_text(); marker='            if t.dep_ == "prep" and t.head.pos_ in {"NOUN", "PROPN"}:';assert text.count(marker)==1;text=text.replace(marker,addition+marker);p.write_text(text)
p=ROOT/'grammar_sentence/src/autosrt_aligner/segmenter_v2.py';text=p.read_text();marker='            cost += internal * (45 if kind == "sentence" else 90)';assert text.count(marker)==1;text=text.replace(marker,'''            cost += internal * (45 if kind == "sentence" else 90)
            if language == "en" and internal and kind != "sentence":
                # A following sentence fragment belongs with its continuation.
                last_sentence_end = strong[bisect.bisect_left(strong, char_end) - 1]
                fragment_words = re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", text[last_sentence_end:char_end])
                cost += 100 if len(fragment_words) <= 3 else 40''');p.write_text(text)
(ROOT/'design.txt').write_text('英语切分独立实验方案\n\n目标：在固定 5 秒、60 字符、原有阅读速度和最短时长约束下，减少紧密短语拆分和完整句后接残片。\n\n方案 A：沿用现有 spaCy 依存分析与全局动态规划；补齐程度修饰、短距离谓语与介词连接、动词与代词宾语。连接仅增加原有软惩罚，不设整类介词禁切，不添加样本文案短语表。\n方案 B：方案 A 加上跨完整句并以残片结尾的惩罚；两端完整的短句组合保持现有规则。\n\n实验：3 个历史项目开发比较；选择及冻结方案后运行另 2 个历史项目；当前心理解说样本仅作回归。所有项目以当前代码在相同设置下重切所得结果作为基线。历史导出字数设置不同，不直接拿旧条数当效果改善。\n\n验证：逐项检查文本连续性、token 时间端点、重叠、字数、时长、阅读速度；独立抽样上下文评审与句法风险计数分开汇报。成功以多项目人工文本对比收益为主，不以门禁通过或风险指标下降代替语意质量。\n\n界限：历史时间证据重放；未重新运行对齐模型或逐条试听。历史验证内容此前被查看过，本轮不用于调参，仍不能称为外部盲测。\n',encoding='utf-8')
print(json.dumps({'directory':str(ROOT),'samples':[{k:d[k] for k in ('id','split','characters','audio_duration')} for d in inputs]},ensure_ascii=False))
