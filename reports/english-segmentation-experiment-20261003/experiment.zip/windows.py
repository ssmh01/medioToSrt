from pathlib import Path
import json,random,bisect,hashlib
ROOT=Path(__file__).resolve().parent; M=json.loads((ROOT/'manifest.json').read_text())
def render(cues,a,b):
 indices=[i for i,c in enumerate(cues) if c['end_char']>a and c['start_char']<b]
 chosen=cues[max(0,indices[0]-1):min(len(cues),indices[-1]+2)] if indices else []
 return '\n'.join(f"{c['start']:.2f}-{c['end']:.2f} ({c['end']-c['start']:.2f}s): {c['text']}" for c in chosen)
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--variant',default='grammar_sentence');ap.add_argument('--split',default='development');args=ap.parse_args();windows=[]
 for item in M['samples']:
  if args.split!='all' and item['split']!=args.split:continue
  ps=[ROOT/'results'/v/item['id']/'cues.json' for v in ['baseline',args.variant]]
  if not all(p.exists() for p in ps):continue
  before,after=[json.loads(p.read_text()) for p in ps];a=json.loads((ROOT/'inputs'/item['id']/'alignment.json').read_text());txt=a['source']['display_text']; ends1={c['end_char'] for c in before[:-1]};ends2={c['end_char'] for c in after[:-1]};changes=sorted(ends1^ends2)
  anchors=[]
  # Source-position-stratified fixed windows, independent of candidate changes.
  rng=random.Random(M['protocol']['selection_seed']+int(hashlib.sha256(item['id'].encode()).hexdigest()[:8],16))
  for i in range(8):
   lo=int(i*len(txt)/8);hi=int((i+1)*len(txt)/8);center=rng.randrange(lo,max(lo+1,hi));anchors.append(('fixed',center))
  # Changed windows are an explicit secondary set, with deterministic spaced coverage.
  spaced=[]
  for p in changes:
   if not spaced or p-spaced[-1]>280:spaced.append(p)
  for p in spaced:anchors.append(('changed',p))
  for kind,center in anchors:
   start=max(0,center-110);end=min(len(txt),center+160);w={'id':f"{item['id']}-{kind}-{len(windows)+1:03}",'sample':item['id'],'split':item['split'],'kind':kind,'start_char':start,'end_char':end,'source':txt[start:end],'baseline':render(before,start,end),args.variant:render(after,start,end),'changed':any(start<p<end for p in changes)};windows.append(w)
 (ROOT/f'windows-{args.variant}-{args.split}.json').write_text(json.dumps(windows,ensure_ascii=False,indent=2))
 text=[]
 for w in windows:
  if not w['changed']:continue
  text.append(f"WINDOW {w['id']} ({w['kind']})\nSOURCE: {w['source']}\nBASELINE:\n{w['baseline']}\nCANDIDATE:\n{w[args.variant]}\n")
 (ROOT/f'windows-{args.variant}-{args.split}.txt').write_text('\n'.join(text))
 print(json.dumps({'windows':len(windows),'fixed':sum(w['kind']=='fixed' for w in windows),'fixed_changed':sum(w['kind']=='fixed' and w['changed'] for w in windows),'changed_windows':sum(w['kind']=='changed' for w in windows)},ensure_ascii=False))
