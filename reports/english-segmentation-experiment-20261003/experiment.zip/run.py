import argparse, json, sys, hashlib, time, bisect, statistics, importlib.util, re
from pathlib import Path
from dataclasses import asdict, replace
from collections import Counter
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--variant',choices=['baseline','grammar','grammar_sentence','grammar_priority','sentence_priority','balanced_priority','sentence_aware','core_priority','final_candidate'],required=True);ap.add_argument('--split',choices=['development','validation','regression','all'],required=True);args=ap.parse_args()
sys.path.insert(0,str(ROOT/args.variant/'src'))
from autosrt_aligner.models import AlignmentToken,SourceDocument
from autosrt_aligner.profiles import resolve_profile
from autosrt_aligner.segmenter_v2 import segment_cues,utterance_ends
from autosrt_aligner.quality_v2 import _segmentation_issues,_reading_char_count,_percentile
from autosrt_aligner.text import validate_subtitle_continuity,is_nonspoken_alignment_char
from autosrt_aligner.formats import export_srt,export_vtt
spec=importlib.util.spec_from_file_location('autosrt_aligner._evaluation_original_rules',ROOT/'baseline/src/autosrt_aligner/language_rules.py');original_rules=importlib.util.module_from_spec(spec);spec.loader.exec_module(original_rules)
manifest=json.loads((ROOT/'manifest.json').read_text());results=[]
for item in manifest['samples']:
 if args.split!='all' and item['split']!=args.split:continue
 p=ROOT/'inputs'/item['id']/'alignment.json';assert hashlib.sha256(p.read_bytes()).hexdigest()==item['input_sha256'];a=json.loads(p.read_text());s=a['source'];text=s['display_text'];source=SourceDocument(text,text,s['align_text'],(),'en',s['source_hash']);ts=[AlignmentToken(**t) for t in a['tokens']];ts.sort(key=lambda t:(t.start_char,t.start));prof=resolve_profile('youtube_long','en',min_duration=1.2,max_duration=5.0,max_chars_total=60);dest=ROOT/'results'/args.variant/item['id'];dest.mkdir(parents=True,exist_ok=True);row={'id':item['id'],'split':item['split'],'variant':args.variant}
 begin=time.perf_counter()
 try:
  cues=segment_cues(source,ts,prof,audio_duration=item['audio_duration']);cues[-1]=replace(cues[-1],end=max(cues[-1].end,item['audio_duration']));row['segmentation_seconds']=round(time.perf_counter()-begin,6)
  assert validate_subtitle_continuity(cues,text)
  assert cues[0].start_char==0 and cues[-1].end_char==len(text)
  assert all(l.end_char==r.start_char for l,r in zip(cues,cues[1:]))
  starts=[t.start_char for t in ts]
  for c in cues:
   ix=bisect.bisect_left(starts,c.start_char); endix=bisect.bisect_left(starts,c.end_char)-1
   assert c.start==ts[ix].start,(c.index,'start')
   expected=max(ts[endix].end,item['audio_duration']) if c.index==len(cues) else ts[endix].end
   assert c.end==expected,(c.index,'end',c.end,expected)
  issues=_segmentation_issues(source,cues,prof);assert not issues,issues
  assert all(r.start>=l.end-.001 for l,r in zip(cues,cues[1:]))
  for fmt,out in [('srt',export_srt(cues,language='en')),('vtt',export_vtt(cues,language='en'))]:
   bodies=[]
   for block in out.strip().split('\n\n'):
    lines=block.splitlines();ind=next((i for i,v in enumerate(lines) if '-->' in v),None)
    if ind is not None:bodies.append(''.join(lines[ind+1:]))
   spoken=lambda st:''.join(c for c in st if not is_nonspoken_alignment_char(c))
   assert spoken(''.join(bodies))==spoken(text),(fmt,'source')
   (dest/f'output.{fmt}').write_text(out,encoding='utf-8')
  analysis=original_rules.analyze(text,'en');maps=original_rules.make_boundary_map(text,'en',analysis);ends={c.end_char for c in cues[:-1]};sent=utterance_ends(text,'en');ds=[c.duration for c in cues];nchars=[len(''.join(c.text.split())) for c in cues];cps=[_reading_char_count(c.text)/c.duration for c in cues];doc=original_rules._model('en')(text);risk_positions=set();risk_kinds=Counter()
  for t in doc:
   if t==t.head:continue
   lo=min(t.idx,t.head.idx);hi=max(t.idx+len(t),t.head.idx+len(t.head));kind=None
   if hi-lo>40:continue
   if t.dep_=='prep' and t.head.pos_ in {'VERB','ADP'} and 0<t.idx-(t.head.idx+len(t.head))<=4:kind='preposition_link'
   elif t.dep_=='advmod' and t.head.pos_ in {'ADJ','ADV','ADP'}:kind='degree_link'
   if kind:
    for cut in ends:
     if lo<cut<hi:risk_positions.add(cut);risk_kinds[kind]+=1
  mixed=sum(any(c.start_char<pos<c.end_char for pos in sent) and original_rules.boundary_kind(text,c.end_char,'en')!='sentence' for c in cues)
  row.update(status='pass',metrics={'cues':len(cues),'word_inside_cuts':sum(maps['word_inside'][p] for p in ends),'original_phrase_inside_cuts':sum(maps['phrase_inside'][p] for p in ends),'new_relation_cut_candidates':len(risk_positions),'new_relation_candidate_types':dict(risk_kinds),'sentence_followed_by_fragment':mixed,'unpunctuated_cuts':sum(original_rules.boundary_kind(text,p,'en')=='weak' for p in ends),'under_2s':sum(d<1.999 for d in ds),'avg_duration':round(statistics.mean(ds),3),'max_duration':round(max(ds),3),'max_chars':max(nchars),'max_cps':round(max(cps),3),'p95_cps':round(_percentile(cps,.95),3),'max_gap':round(max(r.start-l.end for l,r in zip(cues,cues[1:])),3),'text_exact':True,'token_endpoints_exact':True,'overlaps':0,'hard_constraint_issues':issues})
  (dest/'cues.json').write_text(json.dumps([asdict(c) for c in cues],ensure_ascii=False,indent=2))
 except Exception as exc:row.update(status='failed',error=str(exc),seconds_to_failure=round(time.perf_counter()-begin,6))
 (dest/'metrics.json').write_text(json.dumps(row,ensure_ascii=False,indent=2));results.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
(ROOT/f'{args.variant}-{args.split}.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
